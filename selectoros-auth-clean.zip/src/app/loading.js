export default function Loading() {
  return <div className="card h-96">Loading...</div>;
}
