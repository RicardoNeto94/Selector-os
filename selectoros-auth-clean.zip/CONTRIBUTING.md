# Contributing

Thank you for your interest in contributing!

However, please note that contributions are **not** welcome (sorry). This repo is meant as a companion to my written guides, and it's important that code stays consistent with the articles.

Please feel free to fork this repo and make any changes you deem necessary instead.

Thank you.
